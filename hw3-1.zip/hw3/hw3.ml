
(* This is from file json.ml in this directory. json.ml
 * contains the main datatype definition we will use throughout the
 * assignment. You will want to look over this file before starting. *)
include Json

(* These come from the parsed_*_bus.ml.
   Each file binds one variable: small_bus_positions (10 reports),
   medium_bus_positions (100 reports), and complete_bus_positions (~1000 reports),
   respectively with the data that you will need to implement
   your homework.
*)
open Json_structures.Parsed_complete_bus
open Json_structures.Parsed_medium_bus
open Json_structures.Parsed_small_bus

(* provided helper function that deduplicates a list *)
let dedup xs = List.sort_uniq compare xs

(* provided helper function that sorts a given list *)
let sort xs = List.sort compare xs

(* provided helper function to convert a float to a string *)
(* OCaml's string_of_float is not quite RFC compliant due to its tendency
   to output whole numbers with trailing decimal points without a zero.
   But, printf does the job how we want. *)
let json_string_of_float f =
  Printf.sprintf "%g" f
  
(* 1 *)
let make_silly_json i =
  failwith "Need to implement: make_silly_json"

(* 2 *)
let rec concat_with (sep, ss) =
  failwith "Need to implement: concat_with"

(* 3 *)
let quote_string s =
  failwith "Need to implement: quote_string"


(* 4 *)
let rec string_of_json j =
  failwith "Need to implement: string_of_json"

(* 5 *)
let rec take (n,xs) = 
  failwith "Need to implement: take"

(* 6 *)
let rec firsts xs = 
  failwith "Need to implement: firsts"

(* 7 *)
(* write your comment here *)

(* 8 *)
let rec assoc (k, xs) =
  failwith "Need to implement: assoc"

(* 9 *)
let dot (j, f) = 
  failwith "Need to implement: dot"

(* 10 *)
let rec dots (j, fs) =
  failwith "Need to implement: dots"
