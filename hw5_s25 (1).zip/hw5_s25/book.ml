(** module type of books*)
module type Book_t =
sig
  type page = string (* concrete *)
  type direction = Forward | Backward
  type book (* abstract *)

  exception OutOfBounds


  (** [bind lst] is a book that includes all pages in [lst], 
     preserving the order of the pages, and is opened to
     the first page, if one exsits.
  *)
  val bind : page list -> book


  (** [unbind b] is a list of all pages in b, with the 
      order preserved. Note that unbind (bind lst) = lst. 
  *)
  val unbind : book -> page list

  (**
   *   [currentPage b] returns a tuple, with the first element indicating
   *   whether the book is opened at the beginning, and the second
   *   element indicate the current page if there is one, or None otherwise.
   *   More specifically, it should return the following values  
   *      (true,  None) iff [b] is empty
   *      (true,  Some p) iff [b] is not empty and opened to its first page [p]
   *      (false, None) iff b is non-empty and opened to the the end of the book
   *      (false,  Some p) iff b is opened to page [p] in the middle of the book 
   *
   *)
  val currentPage : book -> bool * page option

  (* [flip dir b] returns a book that is flipped the given book
   * [b] in the direction [dir] by one page, if that is possible;
   * or reaise OutOfBounds otherwise.
   * More Specifically,
   *   flip Forward b raises OutOfBounds iff
   *     currentPage b is the end of b
   *
   *   flip Forward b = b' otherwise,
   *     where currentPage b' is the next page in b
   *
   *   flip Backward b raises OutOfBounds iff
   *     currentPage b is the beginning of b
   *
   *   flip Backward b = b' otherwise,
   *     where currentPage b' is the previous page in b
   *)
  val flip : direction -> book -> book
end



module Book : Book_t = struct
  type page = string
  type direction = Forward | Backward
  type book = ??  (**comments*)

  exception OutOfBounds



  (** your comments
  * What is the worse case running time complexity of your function? Why?
  *
  
  let bind 
  *)

  (** your comments
  * What is the worse case running time complexity of your function? Why?
  *
  
  let unbind ...
  *)

  (** your comments    
  * Efficiency goal: O(1)
  * What is the worse case running time complexity of your function? Why?
  * 
  *

  let currentPage  
  *)

  (** your comments
  * What is the worse case running time complexity of your function? Why?
  *

  let flip ...
  *)

end