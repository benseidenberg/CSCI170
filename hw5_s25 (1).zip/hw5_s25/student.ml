
(**module type of like criteria*)
module type Like_Criteria_t = sig
  val favoriteWord : string
  val minCount : int
end

(**module type of students*)
module type Student_t =
sig
  type thoughts (* abstract *)

  type status (* concrete *)
    = Yes
    | No
    | Maybe of thoughts * Book.direction


  val start : thoughts  (* the student's starting thoughts *)

  (**  [think t p] returns the student's like [status]
   *   of the book, considering the given thoughts [t] and 
   *   the information about the current page [p]. More
   *   specifically, 
   *     [think t p] returns [Yes] iff the student "likes" the book
   *     [think t p] returns [No] iff the student "dislikes" the book
   *     [think t p] returns [Maybe (t',d)] iff the student remains
   *       undecided, with updated thoughts [t'] and a direction
   *       [d] in which to flip the book in future steps
   *)
   val think : thoughts -> (bool * Book.page option) -> status

   (* [read b] is true iff Student's status is [Yes]
    *     upon thinking repeatedly about the pages of [b]
          until seeing [minCount] occurrences of the [favoriteWord],
    *  or false iff Student's status is [No]
    *     upon thinking repeatedly about the pages of [b]
          until reaching the end of the book [b] and still not
          seeing [minCount] of the [favoriteWord],
    *  starting from the first page and going forward
    *)
    val read : Book.book -> bool
end

(** functor for creating a student module from the given [Criteria]*)
module MkStudent (Criteria: Like_Criteria_t) : Student_t = struct
  type thoughts = ??

  type status
    = Yes
    | No
    | Maybe of thoughts * Book.direction

  let start = ??  (* the student's starting thoughts *)

  (** your comments
  * What is the worse case running time complexity of your function? Why?

  let think  ...
  *)

  (** your comments
  * What is the worse case running time complexity of your function? Why?

  let read  ...
  *)

end