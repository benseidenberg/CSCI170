open OUnit2
open Book
open Student

let book_empty = Book.bind []

let book_2pages = Book.bind ["lambda";"function"]

let book_2pages_fd = (book_2pages |> Book.flip Book.Forward)

module Lambda_1 : Like_Criteria_t = struct
  let favoriteWord  = "lambda" 
  let minCount = 1
end

module Student_lambda_1 = MkStudent(Lambda_1)

let tests = "test suite for Book" >::: [
  "book empty, unbind" >:: 
    (fun _ -> assert_equal [] (Book.unbind book_empty));
  "book 2pages at the beginning, unbind" >:: 
    (fun _ -> assert_equal ["lambda";"function"]  
                           (Book.unbind book_2pages));
  "book 2pages forwarded, unbind" >:: 
    (fun _ -> assert_equal ["lambda";"function"] 
                           (Book.unbind book_2pages_fd));

  "book empty, current page" >:: 
    (fun _ -> assert_equal (true, None)  
                           (Book.currentPage book_empty));
  "book 2pages at the beginning, current page" >:: 
    (fun _ -> assert_equal (true, Some "lambda")  
                           (Book.currentPage book_2pages));
  "book 2pages forwarded, current page" >:: 
    (fun _ -> assert_equal (false, Some "function") 
                           (Book.currentPage book_2pages_fd));


  "book empty, flip backward" >:: 
    (fun _ -> assert_raises (Book.OutOfBounds)  
                     (fun () -> Book.(flip Backward book_empty)));  



  "student lambda 1, read book_empty " >::
    (fun _ -> assert_equal false (Student_lambda_1.read book_empty));

  "student lambda 1, read book_2pages " >::
    (fun _ -> assert_equal true (Student_lambda_1.read book_2pages));

  "student lambda 1, read book_2pages_fd " >::
    (fun _ -> assert_equal false (Student_lambda_1.read book_2pages_fd));
]

let _ = run_test_tt_main tests